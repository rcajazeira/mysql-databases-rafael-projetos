-- Criação do banco de dados
CREATE DATABASE HospitalDB;
USE HospitalDB;

-- Tabela Horario
CREATE TABLE Horario (
    id_hora_pk INT PRIMARY KEY,
    atendimento_hora TIME,
    emergencia_hora TIME,
    operacao_hora TIME,
    plantao_hora TIME,
    data_hora DATE
);

-- Tabela Departamento
CREATE TABLE Departamento (
    id_dep_pk INT PRIMARY KEY,
    descricao_dep VARCHAR(100)
);

-- Tabela Contato
CREATE TABLE Contato (
    id_con_pk INT PRIMARY KEY,
    tipo_con VARCHAR(50),
    descricao_con VARCHAR(100)
);

-- Tabela Endereco
CREATE TABLE Endereco (
    id_end_pk INT PRIMARY KEY,
    pais_end VARCHAR(50),
    estado_end VARCHAR(50),
    cidade_end VARCHAR(50),
    bairro_end VARCHAR(50),
    logradouro_end VARCHAR(100),
    numero_end VARCHAR(10),
    cep_end VARCHAR(10),
    referencia_end VARCHAR(100),
    complemento_end VARCHAR(100)
);

-- Tabela Hospital
CREATE TABLE Hospital (
    id_hosp_pk INT PRIMARY KEY,
    cnpj_hosp VARCHAR(18),
    razao_social_hosp VARCHAR(100),
    nome_fantasia_hosp VARCHAR(100),
    representante_legal_hosp VARCHAR(100),
    id_end_fk INT,
    FOREIGN KEY (id_end_fk) REFERENCES Endereco(id_end_pk)
);

-- Tabela Funcionario
CREATE TABLE Funcionario (
    id_matricula_pk INT PRIMARY KEY,
    nome_fun VARCHAR(100),
    cpf_fun VARCHAR(14),
    data_nasc_fun DATE,
    salario_fun DECIMAL(10, 2),
    data_de_admissao_fun DATE,
    data_de_finalizacao_de_contrato_fun DATE,
    tipo_de_contrato VARCHAR(50),
    id_dep_fk INT,
    id_con_fk INT,
    id_hora_fk INT,
    id_hosp_fk INT,
    FOREIGN KEY (id_dep_fk) REFERENCES Departamento(id_dep_pk),
    FOREIGN KEY (id_con_fk) REFERENCES Contato(id_con_pk),
    FOREIGN KEY (id_hora_fk) REFERENCES Horario(id_hora_pk),
    FOREIGN KEY (id_hosp_fk) REFERENCES Hospital(id_hosp_pk)
);

-- Tabela Plano
CREATE TABLE Plano (
    id_plano_pk INT PRIMARY KEY,
    nome_plano VARCHAR(100),
    modalidade_plano VARCHAR(50),
    descricao_plano VARCHAR(100),
    orcamento_plano DECIMAL(10, 2)
);

-- Tabela Paciente
CREATE TABLE Paciente (
    id_paci_pk INT PRIMARY KEY,
    nome_paci VARCHAR(100),
    cpf_paci VARCHAR(14),
    data_nasc_paci DATE,
    plano_paci VARCHAR(50),
    enfermidade_paci VARCHAR(100),
    id_plano_fk INT,
    id_end_fk INT,
    id_hosp_fk INT,
    FOREIGN KEY (id_plano_fk) REFERENCES Plano(id_plano_pk),
    FOREIGN KEY (id_end_fk) REFERENCES Endereco(id_end_pk),
    FOREIGN KEY (id_hosp_fk) REFERENCES Hospital(id_hosp_pk)
);

-- Tabela Fornecedor
CREATE TABLE Fornecedor (
    id_forn_pk INT PRIMARY KEY,
    cnpj_forn VARCHAR(18),
    descricao_forn VARCHAR(100),
    razao_social_forn VARCHAR(100),
    representante_legal_forn VARCHAR(100),
    data_fundacao_forn DATE,
    nome_fantasia_forn VARCHAR(100),
    id_end_fk INT,
    FOREIGN KEY (id_end_fk) REFERENCES Endereco(id_end_pk)
);

-- Tabela Farmacia
CREATE TABLE Farmacia (
    id_farm_pk INT PRIMARY KEY,
    nome_farm VARCHAR(100),
    descricao_farm VARCHAR(100),
    dosagem_farm VARCHAR(50),
    id_forn_fk INT,
    FOREIGN KEY (id_forn_fk) REFERENCES Fornecedor(id_forn_pk)
);

-- Atividades

-- 1. INSERT (mínimo 4 por tabela)

-- Tabela Horario

INSERT INTO Horario (id_hora_pk, atendimento_hora, emergencia_hora, operacao_hora, plantao_hora, data_hora)
VALUES 
(1, '08:00:00', '18:00:00', '10:00:00', '22:00:00', '2023-10-01'),
(2, '09:00:00', '19:00:00', '11:00:00', '23:00:00', '2023-10-02'),
(3, '07:00:00', '17:00:00', '09:00:00', '21:00:00', '2023-10-03'),
(4, '10:00:00', '20:00:00', '12:00:00', '00:00:00', '2023-10-04');

-- Tabela Departamento

INSERT INTO Departamento (id_dep_pk, descricao_dep)
VALUES 
(1, 'Pediatria'),
(2, 'Cardiologia'),
(3, 'Ortopedia'),
(4, 'Emergência');

-- Tabela Contato

INSERT INTO Contato (id_con_pk, tipo_con, descricao_con)
VALUES 
(1, 'Telefone', '(11) 9999-8888'),
(2, 'Email', 'joao@hospital.com'),
(3, 'Telefone', '(11) 7777-6666'),
(4, 'Email', 'maria@hospital.com');

-- Tabela Endereco

INSERT INTO Endereco (id_end_pk, pais_end, estado_end, cidade_end, bairro_end, logradouro_end, numero_end, cep_end, referencia_end, complemento_end)
VALUES 
(1, 'Brasil', 'SP', 'São Paulo', 'Centro', 'Rua A', '123', '01000-000', 'Próximo ao metrô', 'Sala 1'),
(2, 'Brasil', 'RJ', 'Rio de Janeiro', 'Copacabana', 'Avenida B', '456', '02000-000', 'Em frente à praia', 'Andar 2'),
(3, 'Brasil', 'MG', 'Belo Horizonte', 'Savassi', 'Rua C', '789', '03000-000', 'Próximo ao shopping', 'Bloco 3'),
(4, 'Brasil', 'RS', 'Porto Alegre', 'Moinhos de Vento', 'Rua D', '101', '04000-000', 'Próximo ao parque', 'Sala 4');

-- Tabela Hospital

INSERT INTO Hospital (id_hosp_pk, cnpj_hosp, razao_social_hosp, nome_fantasia_hosp, representante_legal_hosp, id_end_fk)
VALUES 
(1, '12.345.678/0001-00', 'Hospital Central', 'HCentral', 'Dr. João Silva', 1),
(2, '98.765.432/0001-00', 'Hospital Cardíaco', 'HCardiaco', 'Dra. Maria Souza', 2),
(3, '11.223.344/0001-00', 'Hospital Ortopédico', 'HOrtopedico', 'Dr. Carlos Lima', 3),
(4, '55.666.777/0001-00', 'Hospital Infantil', 'HInfantil', 'Dra. Ana Costa', 4);

-- Tabela Funcionario

INSERT INTO Funcionario (id_matricula_pk, nome_fun, cpf_fun, data_nasc_fun, salario_fun, data_de_admissao_fun, data_de_finalizacao_de_contrato_fun, tipo_de_contrato, id_dep_fk, id_con_fk, id_hora_fk, id_hosp_fk)
VALUES 
(1, 'João Silva', '123.456.789-00', '1980-05-15', 5000.00, '2010-01-01', NULL, 'CLT', 1, 1, 1, 1),
(2, 'Maria Souza', '987.654.321-00', '1985-10-20', 6000.00, '2012-03-15', NULL, 'PJ', 2, 2, 2, 2),
(3, 'Carlos Lima', '111.222.333-44', '1990-07-25', 5500.00, '2015-06-10', NULL, 'CLT', 3, 3, 3, 3),
(4, 'Ana Costa', '555.666.777-88', '1995-12-30', 7000.00, '2018-09-20', NULL, 'PJ', 4, 4, 4, 4);

-- Tabela Plano

INSERT INTO Plano (id_plano_pk, nome_plano, modalidade_plano, descricao_plano, orcamento_plano)
VALUES 
(1, 'Plano Básico', 'Individual', 'Cobertura básica', 1000.00),
(2, 'Plano Familiar', 'Familiar', 'Cobertura para família', 3000.00),
(3, 'Plano Premium', 'Individual', 'Cobertura completa', 5000.00),
(4, 'Plano Empresarial', 'Empresarial', 'Cobertura para empresas', 10000.00);

-- Tabela Paciente

INSERT INTO Paciente (id_paci_pk, nome_paci, cpf_paci, data_nasc_paci, plano_paci, enfermidade_paci, id_plano_fk, id_end_fk, id_hosp_fk)
VALUES 
(1, 'Pedro Alves', '999.888.777-66', '1990-01-01', 'Básico', 'Gripe', 1, 1, 1),
(2, 'Luiza Mendes', '888.777.666-55', '1985-05-10', 'Familiar', 'Dor nas costas', 2, 2, 2),
(3, 'Fernando Costa', '777.666.555-44', '2000-10-20', 'Premium', 'Fratura', 3, 3, 3),
(4, 'Carla Dias', '666.555.444-33', '1995-12-15', 'Empresarial', 'Hipertensão', 4, 4, 4);

-- Tabela Fornecedor

INSERT INTO Fornecedor (id_forn_pk, cnpj_forn, descricao_forn, razao_social_forn, representante_legal_forn, data_fundacao_forn, nome_fantasia_forn, id_end_fk)
VALUES 
(1, '12.345.678/0001-00', 'Fornecedor de Medicamentos', 'Farma Ltda', 'José Oliveira', '2000-01-01', 'Farma', 1),
(2, '98.765.432/0001-00', 'Fornecedor de Equipamentos', 'EquipMed S.A.', 'Ana Santos', '2005-05-05', 'EquipMed', 2),
(3, '11.223.344/0001-00', 'Fornecedor de Alimentos', 'NutriFood', 'Carlos Mendes', '2010-10-10', 'NutriFood', 3),
(4, '55.666.777/0001-00', 'Fornecedor de Limpeza', 'CleanHouse', 'Luiza Fernandes', '2015-12-15', 'CleanHouse', 4);

-- Tabela Farmacia

INSERT INTO Farmacia (id_farm_pk, nome_farm, descricao_farm, dosagem_farm, id_forn_fk)
VALUES 
(1, 'Paracetamol', 'Analgésico e antitérmico', '500mg', 1),
(2, 'Amoxicilina', 'Antibiótico', '250mg', 2),
(3, 'Dipirona', 'Analgésico', '1g', 3),
(4, 'Omeprazol', 'Protetor gástrico', '20mg', 4);

-- 2. UPDATE (mínimo 2 por tabela)

-- Tabela Horario

UPDATE Horario SET atendimento_hora = '08:30:00' WHERE id_hora_pk = 1;
UPDATE Horario SET emergencia_hora = '19:30:00' WHERE id_hora_pk = 2;

-- Tabela Funcionario

UPDATE Funcionario SET salario_fun = 5500.00 WHERE id_matricula_pk = 1;
UPDATE Funcionario SET tipo_de_contrato = 'CLT' WHERE id_matricula_pk = 2;

-- Tabela Paciente


UPDATE Paciente SET enfermidade_paci = 'Resfriado' WHERE id_paci_pk = 1;
UPDATE Paciente SET plano_paci = 'Premium' WHERE id_paci_pk = 2;

-- Tabela Fornecedor

UPDATE Fornecedor SET descricao_forn = 'Fornecedor de Medicamentos e Equipamentos' WHERE id_forn_pk = 1;
UPDATE Fornecedor SET nome_fantasia_forn = 'FarmaPlus' WHERE id_forn_pk = 2;
-- 3. DELETE (mínimo 1 por tabela, usando BETWEEN e LIKE)

-- Tabela Horario

DELETE FROM Horario WHERE id_hora_pk BETWEEN 3 AND 4;

-- Tabela Funcionario

DELETE FROM Funcionario WHERE nome_fun LIKE '%Silva%';

-- Tabela Paciente

DELETE FROM Paciente WHERE id_paci_pk BETWEEN 2 AND 3;

-- Tabela Fornecedor

DELETE FROM Fornecedor WHERE nome_fantasia_forn LIKE '%Food%';

-- 4. SELECT (3 exemplos com cláusulas WHERE e operadores especiais)

-- Exemplo 1: Selecionar funcionários com salário maior que 5000

SELECT nome_fun, salario_fun
FROM Funcionario
WHERE salario_fun > 5000;

-- Objetivo: Listar funcionários com salário acima de 5000.

-- Exemplo 2: Selecionar pacientes com plano "Premium"

SELECT nome_paci, plano_paci
FROM Paciente
WHERE plano_paci = 'Premium';

-- Objetivo: Listar pacientes que possuem o plano "Premium".
-- Exemplo 3: Selecionar fornecedores fundados após 2010

SELECT nome_fantasia_forn, data_fundacao_forn
FROM Fornecedor
WHERE data_fundacao_forn > '2010-01-01';

-- Objetivo: Listar fornecedores fundados após 2010.

-- 5. TRIGGER

-- Trigger para registrar alterações na tabela Funcionario

-- Altera o delimitador temporariamente
DELIMITER //

-- Cria o trigger
CREATE TRIGGER trg_after_update_funcionario
AFTER UPDATE ON Funcionario
FOR EACH ROW
BEGIN
    -- Insere os dados na tabela Log_Funcionario
    INSERT INTO Log_Funcionario (id_matricula_pk, nome_fun, salario_antigo, salario_novo, data_alteracao)
    VALUES (OLD.id_matricula_pk, OLD.nome_fun, OLD.salario_fun, NEW.salario_fun, NOW());
END; //

-- Restaura o delimitador padrão
DELIMITER ;

-- Objetivo: Registrar alterações de salário dos funcionários.

6. STORED PROCEDURE
Procedure para calcular a média salarial dos funcionários

DELIMITER //
CREATE PROCEDURE CalcularMediaSalarial()
BEGIN
    SELECT AVG(salario_fun) AS media_salarial
    FROM Funcionario;
END //
DELIMITER ;

-- Objetivo: Calcular a média salarial dos funcionários.

7. FUNCTION
Function para contar o número de pacientes por hospital
sql
Copy
DELIMITER //

CREATE FUNCTION ContarPacientesPorHospital(hosp_id INT)
RETURNS INT
DETERMINISTIC

BEGIN
    DECLARE total_pacientes INT;
    SELECT COUNT(*) INTO total_pacientes
    FROM Paciente
    WHERE id_hosp_fk = hosp_id;
    RETURN total_pacientes;
END //
DELIMITER ;

-- Objetivo: Retornar o número de pacientes de um hospital específico.