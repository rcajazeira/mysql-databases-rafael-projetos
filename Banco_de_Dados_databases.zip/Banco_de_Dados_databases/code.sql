UPDATE Cliente
SET renda_cli = renda_cli * 0.9  -- Subtrai 10% da renda
WHERE id_cli_pk IN (1, 5);