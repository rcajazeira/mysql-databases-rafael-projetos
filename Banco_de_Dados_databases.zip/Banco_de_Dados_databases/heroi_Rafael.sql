CREATE DATABASE BD_Herois2;
USE BD_Herois2;

CREATE TABLE Origem (
cod_ori_pk INT PRIMARY KEY,
nome_ori VARCHAR(200) NOT NULL
);

INSERT INTO Origem VALUES (1, 'Marvel');
INSERT INTO Origem VALUES (2, 'DC Comics');
INSERT INTO Origem VALUES (3, 'TV');
INSERT INTO Origem VALUES (4, 'Internet');

CREATE TABLE Heroi (
cod_hero_pk INT PRIMARY KEY,
nome_hero VARCHAR (200) NOT NULL,
arma_hero VARCHAR (100),
cod_ori_fk INT,
FOREIGN KEY (cod_ori_fk) REFERENCES Origem (cod_ori_pk)
);

INSERT INTO heroi VALUES (1, 'Capitão America', 'Escudo', 1);
INSERT INTO heroi VALUES (2, 'Homem de Ferro', 'Armadura', 1);
INSERT INTO heroi (cod_hero_pk, nome_hero) VALUES (3, 'Huck');
INSERT INTO heroi (cod_hero_pk, nome_hero, cod_ori_fk) VALUES (4, 'Power Rangers', 3);
INSERT INTO heroi (cod_hero_pk, nome_hero) VALUES (5, 'Big Hero');
INSERT INTO heroi VALUES (6, 'Homem-Aranha', 'Teia', 1);
INSERT INTO heroi VALUES (7, 'Super Homem', 'Força', 2);
INSERT INTO heroi VALUES (8, 'Batman', 'Dinheiro', 2);
INSERT INTO heroi VALUES (9, 'Seya de Pegasus', 'Cosmo', 3);

SELECT * FROM Heroi;
SELECT * FROM Origem;

SELECT 
ORIGEM.nome_ori AS 'Origem',
HEROI.nome_hero AS 'Nome Heroi'
FROM origem CROSS JOIN heroi;

SELECT
ORIGEM.nome_ori AS 'Origem',
HEROI.nome_hero AS 'Nome Heroi'
FROM Origem 
JOIN Heroi
ON (ORIGEM.cod_ori_pk = HEROI.cod_ori_fk);

SELECT
HEROI.nome_hero AS 'Nome Heroi',
ORIGEM.nome_ori AS 'Origem'
FROM
HEROI RIGHT JOIN ORIGEM
ON (ORIGEM.cod_ori_pk = HEROI.cod_ori_fk);

CREATE VIEW nome_hero_origem AS
SELECT
HEROI.nome_hero AS 'Nome Heroi',
ORIGEM.nome_ori AS 'Origem'
FROM
HEROI LEFT JOIN ORIGEM
ON (ORIGEM.cod_ori_pk = HEROI.cod_ori_fk)
WHERE arma_hero IS NULL;
-- WHERE (HEROI.arma_hero = 'dinheiro') OR (HEROI.arma_hero = 'teia');

CREATE VIEW Origem_e_Armas AS
SELECT
ORIGEM.nome_ori AS 'Origem',
HEROI.arma_hero AS 'Arma'
FROM
Heroi RIGHT JOIN Origem
ON (ORIGEM.cod_ori_pk = HEROI.cod_ori_fk);

SELECT * FROM origem_e_armas;

DESC origem_e_armas;

DESC origem;

DROP VIEW origem_e_armas;

-- aula 27/02/2024

CREATE VIEW Herois_e_Origem AS
SELECT 
ORIGEM.nome_ori AS 'Origem', 
HEROI.nome_hero AS 'Nome do Herói'
FROM 
ORIGEM, HEROI
WHERE
(HEROI.cod_ori_fk = ORIGEM.cod_ori_pk);

SELECT * FROM Herois_e_Origem;

DESC herois_e_origem;

-- Objetivo: Listar todos os nomes das origens e as armas associadas aos heróis
SELECT
  ORIGEM.nome_ori AS 'Origem',
  HEROI.arma_hero AS 'Arma'
FROM
  Origem
JOIN
  Heroi
ON
  ORIGEM.cod_ori_pk = HEROI.cod_ori_fk;
  
  -- Objetivo: Listar os heróis que têm a origem "Marvel"
SELECT
  HEROI.nome_hero AS 'Nome Heroi'
FROM
  Heroi
JOIN
  Origem
ON
  HEROI.cod_ori_fk = Origem.cod_ori_pk
WHERE
  Origem.nome_ori = 'Marvel';
  
  -- Objetivo: Listar os heróis com a arma 'dinheiro' e suas origens
SELECT
  HEROI.nome_hero AS 'Nome Heroi',
  ORIGEM.nome_ori AS 'Origem'
FROM
  Heroi
JOIN
  Origem
ON
  HEROI.cod_ori_fk = Origem.cod_ori_pk
WHERE
  HEROI.arma_hero = 'Dinheiro';
  
  -- Objetivo: Listar heróis que possuem armas e suas respectivas origens
SELECT
  HEROI.nome_hero AS 'Nome Heroi',
  HEROI.arma_hero AS 'Arma',
  ORIGEM.nome_ori AS 'Origem'
FROM
  Heroi
JOIN
  Origem
ON
  HEROI.cod_ori_fk = Origem.cod_ori_pk
WHERE
  HEROI.arma_hero IS NOT NULL;




