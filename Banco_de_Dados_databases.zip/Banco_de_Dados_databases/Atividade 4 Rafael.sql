-- Atividade parte 4

-- Tabela Pais

show tables;
select * from Pais;

INSERT INTO Pais (id_pais_pk, nome_pais, ddi_pais, continente_pais)
VALUES (3, 'Uruguai', 598, 'America do Sul');

INSERT INTO Pais (id_pais_pk, nome_pais, ddi_pais, continente_pais)
VALUES (4, 'Argentina', 54, 'America do Sul');

INSERT INTO Pais 
VALUES (5, 'Chile', 56, 'America do Sul');

INSERT INTO Pais 
VALUES (6, 'Guiana Francesa', 594, 'America do Sul');

-- Tabela Estado

show tables;
select * from Estado;

INSERT INTO Estado (id_est_pk, nome_est, sigla_est, regiao_est, id_pais_fk)
VALUES (2, 'Bahia', 'BA', 'Nordeste', 1);

INSERT INTO Estado (id_est_pk, nome_est, sigla_est, regiao_est, id_pais_fk)
VALUES (3, 'Piaui', 'PI', 'Nordeste', 1);

INSERT INTO Estado 
VALUES (4, 'Maranhao', 'MA', 'Nordeste', 1);

INSERT INTO Estado
VALUES (5, 'Ceara', 'CE', 'Nordeste', 1);

-- Tabela Cidade

show tables;
select * from Cidade;

INSERT INTO Cidade (id_cid_pk, nome_cid, data_criacao_cid, id_est_fk)
VALUES (1, 'Salvador', '1900-11-20', 1);

INSERT INTO Cidade (id_cid_pk, nome_cid, data_criacao_cid, id_est_fk)
VALUES (2, 'Camaçari', '1900-11-20', 1);

INSERT INTO Cidade 
VALUES (3, 'Lauro de Freitas', '1900-11-20', 1);

INSERT INTO Cidade
VALUES (4, 'Feira de Santana', '1900-11-20', 1);

-- Tabela Endereco

show tables;
select * from Endereco;

INSERT INTO Endereco (id_end_pk, rua_end, numero_end, bairro_end, id_cid_fk, referencia_end)
VALUES (1, 'Rua das Valquirias', '33', 'Pirui', 1, 'perto das marocas');

INSERT INTO Endereco (id_end_pk, rua_end, numero_end, bairro_end, id_cid_fk, referencia_end)
VALUES (2, 'Rua Galego', '304', 'Taboao', 1, 'perto do Centro');

INSERT INTO Endereco 
VALUES (3, 'Rua Chile', '200', 'Centro', 1, 'Abaixo da ladeira');

INSERT INTO Endereco
VALUES (4, 'Rua da Barreras', '405', 'Gales', 1, 'Rio Sena na frente');

-- Tabela Cliente

show tables;
select * from Cliente;

INSERT INTO Cliente (id_cli_pk, nome_cli, cpf_cli, data_nasc_cli, genero_cli, email_cli, id_end_fk, tipo_sanguineo_cli, rg_cli, telefone)
VALUES (1, 'Klingue', '00045821985417', '1981-09-22', 'F', 'kling@gmail.com', 1, 'AB+', '768788882', '719886254');

INSERT INTO Cliente (id_cli_pk, nome_cli, cpf_cli, data_nasc_cli, genero_cli, email_cli, id_end_fk, tipo_sanguineo_cli, rg_cli, telefone)
VALUES (2, 'Juliete', '00045876985417', '1990-11-02', 'F', 'Ju2d@gmail.com', 2, 'AB-', '768704182', '719860154');

INSERT INTO Cliente 
VALUES (3, 'Humberto', '00430876985417', '1993-03-11', 'M', 'humbdois@gmail.com', 3, 'O', '761114182', '719867814');

INSERT INTO Cliente 
VALUES (4, 'Tulio', '00430876605417', '1998-06-17', 'M', 'tuliosales@gmail.com', 4, 'B-', '650114182', '759867014');