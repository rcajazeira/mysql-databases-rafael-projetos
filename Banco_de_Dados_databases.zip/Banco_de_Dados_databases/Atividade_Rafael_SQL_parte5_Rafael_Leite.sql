-- Prática SQL 01, parte 5 Rafael Leite

-- 1 Teste de UPDATES

SHOW DATABASES;
USE Locadora;
SHOW TABLES;
DESCRIBE Pais;
SELECT * FROM Pais;

UPDATE Pais
SET ddi_pais = 1
WHERE id_pais_pk;

DESCRIBE Cliente;
SELECT * FROM Cliente;

ALTER TABLE Cliente
DROP COLUMN rg_cli;

ALTER TABLE Cliente
ADD COLUMN renda_cli DOUBLE;

UPDATE Cliente
SET renda_cli = renda_cli + 150
WHERE data_nasc_cli >= '2000-01-01';

UPDATE Cliente
SET renda_cli = renda_cli + 10000
WHERE data_nasc_cli < '2000-01-01';

UPDATE Cliente
SET renda_cli = 10000
WHERE id_cli_pk = 4;

UPDATE Cliente
SET renda_cli = renda_cli * 0.8
WHERE id_cli_pk = 1 OR id_cli_pk = 5;

 UPDATE Cliente 
SET renda_cli = renda_cli * 1.2
WHERE (tipo_sanguineo_cli = 'B+') AND (tipo_sanguineo_cli = 'B-');

UPDATE Cliente
SET nome_cli = 'Lucas Matos'
WHERE id_cli_pk = 2;

UPDATE Cliente
SET renda_cli = renda_cli * 1.20
WHERE data_nasc_cli < '2000-01-01';

UPDATE Cliente
SET renda_cli = renda_cli * 0.73
WHERE renda_cli >= 5000;

UPDATE Cliente
SET data_nasc_cli = '1981-09-27'
WHERE id_cli_pk = 1;

INSERT INTO Cliente 
VALUES (7, 'Alice', '00438876605417', '2000-06-27', 'F', 'alicemeira@gmail.com', 4, 'AB+', '7598670887', 2000.33);

INSERT INTO Cliente 
VALUES (8, 'Jose', '00430876095417', '2002-10-07', 'M', 'jalves@gmail.com', 4, 'AB-', '759867065', 6700.32);

INSERT INTO Cliente 
VALUES (9, 'Fernando', '00430436605417', '2004-05-18', 'M', 'nandomaravilha@gmail.com', 4, 'B-', '759867514', 5200.90);

INSERT INTO Cliente 
VALUES (10, 'Horácio', '00430854605417', '2008-08-01', 'M', 'hcajazeira@gmail.com', 4, 'B+', '7599877014', 3450.00);

INSERT INTO Cliente 
VALUES (11, 'Helen', '00430876935417', '2011-01-30', 'F', 'helensilva@gmail.com', 4, 'A+', '759977014', 4500.00);

INSERT INTO Cliente 
VALUES (12, 'Charles', '00433376605417', '2013-09-03', 'M', 'charles22@gmail.com', 4, 'A-', '729967114', 6000.00);
