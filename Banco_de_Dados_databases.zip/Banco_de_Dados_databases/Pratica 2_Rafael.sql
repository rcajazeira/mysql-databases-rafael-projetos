/*
palavras reservadas: MAIÚSCULAS
nome de database: nesse_modelo
nome de entidade: Nesse_Modelo
nome de atributo: nesse_modelo
*/

-- criar o banco de dados
CREATE DATABASE locadora;

-- excluir o banco de dados
DROP DATABASE locadora;

USE locadora;
-- PARA USAR O BANCO DE DADOS

-- criar tabela Cliente
CREATE TABLE Cliente (
	id_cli_pk INTEGER PRIMARY KEY,
	nome_cli VARCHAR(100),
	cpf_cli VARCHAR(15),
	data_cli DATE,
	sexo_cli VARCHAR(10),
	email_cli VARCHAR(100)
);

CREATE TABLE Cidade (
	id_cid_pk INTEGER PRIMARY KEY,
	nome_cid VARCHAR(100),
	data_criacao_cid DATE
);

CREATE TABLE Endereco (
	id_end_pk INTEGER PRIMARY KEY,
	rua_end VARCHAR(100),
	numero_end VARCHAR(15),
	bairro_end VARCHAR(20)
);

CREATE TABLE Estado (
	id_est_pk INTEGER PRIMARY KEY,
	nome_est VARCHAR(100),
	sigla_est VARCHAR(15),
	regiao_est VARCHAR(10)
);

CREATE TABLE Pais (
	id_pais_pk INTEGER PRIMARY KEY,
	nome_pais VARCHAR(100),
	continente_pais VARCHAR(15)
);

-- para deletar tabela

DROP TABLE Cliente;
DROP TABLE Cidade;
DROP TABLE Endereco;
DROP TABLE Estado;
DROP TABLE Pais;

CREATE TABLE Estado (
	id_est_pk INTEGER PRIMARY KEY,
	nome_est VARCHAR(20),
	sigla_est VARCHAR(2),
	regiao_est VARCHAR(10),
	-- chave estrangeira da tabela país
	id_pais_fk INTEGER,
	FOREIGN KEY (id_pais_fk) REFERENCES Pais (id_pais_pk)
);

-- cria cidade

CREATE TABLE Cidade (
	id_cid_pk INTEGER PRIMARY KEY,
	nome_cid VARCHAR(100),
	data_criacao_cid DATE,
	-- cria chave estrangeira da tabela estado
	id_est_fk INTEGER,
    FOREIGN KEY (id_est_fk) REFERENCES Estado (id_est_pk)
);

CREATE TABLE Endereco (
	id_end_pk INTEGER PRIMARY KEY,
	rua_end VARCHAR(100),
	numero_end VARCHAR(15),
	bairro_end VARCHAR(20),
	-- cria chave estrangeira de cidade
	id_cid_fk INTEGER,
    FOREIGN KEY (id_cid_fk) REFERENCES Cidade (id_cid_pk)

);

CREATE TABLE Cliente (
	id_cli_pk INTEGER PRIMARY KEY,
	nome_cli VARCHAR(100),
	cpf_cli VARCHAR(15),
	data_cli DATE,
	sexo_cli VARCHAR(10),
	email_cli VARCHAR(100),
    -- cria chave estrangeira de endereco
    id_end_fk INTEGER,
    FOREIGN KEY (id_end_fk) REFERENCES Endereco (id_end_pk)
);

show databases;

use locadora;

show tables;

select * from Cliente;
select * from Endereco;
select * from pais;

-- para adicionar atributos em tabelas, add atributo a tabela existente

ALTER TABLE Cliente 
ADD renda_cli FLOAT;

ALTER TABLE Endereco 
ADD referencia_end VARCHAR(100);

ALTER TABLE Pais 
ADD ddi_pais INTEGER;

ALTER TABLE Cliente 
ADD tipo_sanguineo_cli VARCHAR(2);

-- modificar atributos
ALTER TABLE Cliente
MODIFY tipo_sanguineo_cli VARCHAR(3);

-- excluir atributos
ALTER TABLE Cliente
DROP renda_cli;

-- renomear atributos
ALTER TABLE Cliente
RENAME COLUMN data_cli TO data_nasc_cli;

-- Atividade 1
ALTER TABLE Cliente 
ADD rg_cli INTEGER(30);

-- Atividade 2
ALTER TABLE Cliente 
ADD telefone VARCHAR(30);

-- Atividade 3
ALTER TABLE Endereco 
ADD referencia_end VARCHAR(255);

-- Atividade 4
ALTER TABLE Pais
DROP continente_pais;

-- Atividade 5
ALTER TABLE Cliente
RENAME COLUMN sexo_cli TO genero_cli;

-- Atividade 6 
ALTER TABLE Cliente
MODIFY  data_nasc_cli DATETIME;






















