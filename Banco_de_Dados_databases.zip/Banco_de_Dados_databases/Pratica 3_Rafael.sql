/*
palavras reservadas: MAIÚSCULAS
nome de database: nesse_modelo
nome de entidade: Nesse_Modelo
nome de atributo: nesse_modelo
*/

-- criar o banco de dados
CREATE DATABASE locadora;

-- excluir o banco de dados
DROP DATABASE locadora;

USE locadora;
-- PARA USAR O BANCO DE DADOS

-- criar tabela Cliente
CREATE TABLE Cliente (
	id_cli_pk INTEGER PRIMARY KEY,
	nome_cli VARCHAR(100),
	cpf_cli VARCHAR(15),
	data_cli DATE,
	sexo_cli VARCHAR(10),
	email_cli VARCHAR(100)
);

CREATE TABLE Cidade (
	id_cid_pk INTEGER PRIMARY KEY,
	nome_cid VARCHAR(100),
	data_criacao_cid DATE
);

CREATE TABLE Endereco (
	id_end_pk INTEGER PRIMARY KEY,
	rua_end VARCHAR(100),
	numero_end VARCHAR(15),
	bairro_end VARCHAR(20)
);

CREATE TABLE Estado (
	id_est_pk INTEGER PRIMARY KEY,
	nome_est VARCHAR(100),
	sigla_est VARCHAR(15),
	regiao_est VARCHAR(10)
);

CREATE TABLE Pais (
	id_pais_pk INTEGER PRIMARY KEY,
	nome_pais VARCHAR(100),
	continente_pais VARCHAR(15)
);

-- para deletar tabela

DROP TABLE Cliente;
DROP TABLE Cidade;
DROP TABLE Endereco;
DROP TABLE Estado;
DROP TABLE Pais;

CREATE TABLE Estado (
	id_est_pk INTEGER PRIMARY KEY,
	nome_est VARCHAR(20),
	sigla_est VARCHAR(2),
	regiao_est VARCHAR(10),
	-- chave estrangeira da tabela país
	id_pais_fk INTEGER,
	FOREIGN KEY (id_pais_fk) REFERENCES Pais (id_pais_pk)
);

-- cria cidade

CREATE TABLE Cidade (
	id_cid_pk INTEGER PRIMARY KEY,
	nome_cid VARCHAR(100),
	data_criacao_cid DATE,
	-- cria chave estrangeira da tabela estado
	id_est_fk INTEGER,
    FOREIGN KEY (id_est_fk) REFERENCES Estado (id_est_pk)
);

CREATE TABLE Endereco (
	id_end_pk INTEGER PRIMARY KEY,
	rua_end VARCHAR(100),
	numero_end VARCHAR(15),
	bairro_end VARCHAR(20),
	-- cria chave estrangeira de cidade
	id_cid_fk INTEGER,
    FOREIGN KEY (id_cid_fk) REFERENCES Cidade (id_cid_pk)

);

CREATE TABLE Cliente (
	id_cli_pk INTEGER PRIMARY KEY,
	nome_cli VARCHAR(100),
	cpf_cli VARCHAR(15),
	data_cli DATE,
	sexo_cli VARCHAR(10),
	email_cli VARCHAR(100),
    -- cria chave estrangeira de endereco
    id_end_fk INTEGER,
    FOREIGN KEY (id_end_fk) REFERENCES Endereco (id_end_pk)
);

show databases;

use locadora;

show tables;

select * from Cliente;
select * from Endereco;
select * from pais;

-- para adicionar atributos em tabelas, add atributo a tabela existente

ALTER TABLE Cliente 
ADD renda_cli FLOAT;

ALTER TABLE Endereco 
ADD referencia_end VARCHAR(100);

ALTER TABLE Pais 
ADD ddi_pais INTEGER;

ALTER TABLE Cliente 
ADD tipo_sanguineo_cli VARCHAR(2);

-- modificar atributos
ALTER TABLE Cliente
MODIFY tipo_sanguineo_cli VARCHAR(3);

-- excluir atributos
ALTER TABLE Cliente
DROP renda_cli;

-- renomear atributos
ALTER TABLE Cliente
RENAME COLUMN data_cli TO data_nasc_cli;

-- Atividade 1
ALTER TABLE Cliente 
ADD rg_cli INTEGER(30);

-- Atividade 2
ALTER TABLE Cliente 
ADD telefone VARCHAR(30);

-- Atividade 3
ALTER TABLE Endereco 
ADD referencia_end VARCHAR(255);

-- Atividade 4
ALTER TABLE Pais
DROP continente_pais;

-- Atividade 5
ALTER TABLE Cliente
RENAME COLUMN sexo_cli TO genero_cli;

-- Atividade 6 
ALTER TABLE Cliente
MODIFY  data_nasc_cli DATETIME;

-- INSERT

INSERT INTO Pais
VALUES (1, 'Brasil', 55);

SELECT * FROM Pais;

INSERT INTO Pais (id_pais_pk, nome_pais, continente_pais)
VALUES (1, 'Brasil', 55);

INSERT INTO Pais (id_pais_pk, nome_pais, continente_pais)
VALUES (2, 'EUA', 'América do Norte');

ALTER TABLE Pais 
ADD continente_pais VARCHAR(100);

-- SELECTS

SELECT * FROM Estado;
SELECT * FROM Pais;

INSERT INTO Estado 
VALUES (1, 'Bahia', 'BA', 'Nordeste', 1);

-- Atividade parte 4

-- Tabela Pais

show tables;
select * from Pais;

INSERT INTO Pais (id_pais_pk, nome_pais, ddi_pais, continente_pais)
VALUES (3, 'Uruguai', 598, 'America do Sul');

INSERT INTO Pais (id_pais_pk, nome_pais, ddi_pais, continente_pais)
VALUES (4, 'Argentina', 54, 'America do Sul');

INSERT INTO Pais 
VALUES (5, 'Chile', 56, 'America do Sul');

INSERT INTO Pais 
VALUES (6, 'Guiana Francesa', 594, 'America do Sul');

-- Tabela Estado

show tables;
select * from Estado;

INSERT INTO Estado (id_est_pk, nome_est, sigla_est, regiao_est, id_pais_fk)
VALUES (2, 'Bahia', 'BA', 'Nordeste', 1);

INSERT INTO Estado (id_est_pk, nome_est, sigla_est, regiao_est, id_pais_fk)
VALUES (3, 'Piaui', 'PI', 'Nordeste', 1);

INSERT INTO Estado 
VALUES (4, 'Maranhao', 'MA', 'Nordeste', 1);

INSERT INTO Estado
VALUES (5, 'Ceara', 'CE', 'Nordeste', 1);

-- Tabela Cidade

show tables;
select * from Cidade;

INSERT INTO Cidade (id_cid_pk, nome_cid, data_criacao_cid, id_est_fk)
VALUES (1, 'Salvador', '1900-11-20', 1);

INSERT INTO Cidade (id_cid_pk, nome_cid, data_criacao_cid, id_est_fk)
VALUES (2, 'Camaçari', '1900-11-20', 1);

INSERT INTO Cidade 
VALUES (3, 'Lauro de Freitas', '1900-11-20', 1);

INSERT INTO Cidade
VALUES (4, 'Feira de Santana', '1900-11-20', 1);

-- Tabela Endereco

show tables;
select * from Endereco;

INSERT INTO Endereco (id_end_pk, rua_end, numero_end, bairro_end, id_cid_fk, referencia_end)
VALUES (1, 'Rua das Valquirias', '33', 'Pirui', 1, 'perto das marocas');

INSERT INTO Endereco (id_end_pk, rua_end, numero_end, bairro_end, id_cid_fk, referencia_end)
VALUES (2, 'Rua Galego', '304', 'Taboao', 1, 'perto do Centro');

INSERT INTO Endereco 
VALUES (3, 'Rua Chile', '200', 'Centro', 1, 'Abaixo da ladeira');

INSERT INTO Endereco
VALUES (4, 'Rua da Barreras', '405', 'Gales', 1, 'Rio Sena na frente');

-- Tabela Cliente

show tables;
select * from Cliente;

INSERT INTO Cliente (id_cli_pk, nome_cli, cpf_cli, data_nasc_cli, genero_cli, email_cli, id_end_fk, tipo_sanguineo_cli, rg_cli, telefone)
VALUES (1, 'Klingue', '00045821985417', '1981-09-22', 'F', 'kling@gmail.com', 1, 'AB+', '768788882', '719886254');

INSERT INTO Cliente (id_cli_pk, nome_cli, cpf_cli, data_nasc_cli, genero_cli, email_cli, id_end_fk, tipo_sanguineo_cli, rg_cli, telefone)
VALUES (2, 'Juliete', '00045876985417', '1990-11-02', 'F', 'Ju2d@gmail.com', 2, 'AB-', '768704182', '719860154');

INSERT INTO Cliente 
VALUES (3, 'Humberto', '00430876985417', '1993-03-11', 'M', 'humbdois@gmail.com', 3, 'O', '761114182', '719867814');

INSERT INTO Cliente 
VALUES (4, 'Tulio', '00430876605417', '1998-06-17', 'M', 'tuliosales@gmail.com', 4, 'B-', '650114182', '759867014');
































