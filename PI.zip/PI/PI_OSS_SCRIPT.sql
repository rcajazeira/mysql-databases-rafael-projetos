-- Criação do banco de dados
DROP DATABASE Observatorio_de_Sustentabilidade;
CREATE DATABASE Observatorio_de_Sustentabilidade;
USE Observatorio_de_Sustentabilidade;

-- Tabela Endereco (deve ser criada primeiro por ser referenciada)
CREATE TABLE Endereco (
    id_end_pk INT PRIMARY KEY AUTO_INCREMENT,
    logradouro_end VARCHAR(100) NOT NULL,
    numero_end VARCHAR(100) NOT NULL,
    complemento_end VARCHAR(100),
    bairro_end VARCHAR(100) NOT NULL,
    cidade_end VARCHAR(100) NOT NULL,
    estado_end VARCHAR(100) NOT NULL,
    cep_end VARCHAR(100) NOT NULL,
    pais_end VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela Contato (criada antes de Usuario)
CREATE TABLE Contato (
    id_con_pk INT PRIMARY KEY AUTO_INCREMENT,
    telefone_con VARCHAR(100) NOT NULL,
    email_con VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela Usuario
CREATE TABLE Usuario (
    id_use_pk INT PRIMARY KEY AUTO_INCREMENT,
    nome_completo_use VARCHAR(100) NOT NULL,
    senha_use VARCHAR(100) NOT NULL,
    data_nasc_use DATE,
    fk_Endereco_id_end_pk INT,
    fk_Contato_id_con_pk INT,
    FOREIGN KEY (fk_Endereco_id_end_pk) REFERENCES Endereco(id_end_pk) ON DELETE SET NULL,
    FOREIGN KEY (fk_Contato_id_con_pk) REFERENCES Contato(id_con_pk) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela Feedback
CREATE TABLE Feedback (
    id_fed_pk INT PRIMARY KEY AUTO_INCREMENT,
    comentario_feed VARCHAR(100) NOT NULL,
    curtida_feed BOOLEAN,
    avaliacao_feed VARCHAR(100),
    views_feed VARCHAR(100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela Noticia
CREATE TABLE Noticia (
    id_noticia_pk INT PRIMARY KEY AUTO_INCREMENT,
    nome_da_noticia VARCHAR(100) NOT NULL,
    tipo_de_noticia VARCHAR(100) NOT NULL,
    data_da_noticia DATE NOT NULL,
    id_use_fk INT NOT NULL,
    fk_Feedback_id_fed_pk INT,
    FOREIGN KEY (id_use_fk) REFERENCES Usuario(id_use_pk) ON DELETE CASCADE,
    FOREIGN KEY (fk_Feedback_id_fed_pk) REFERENCES Feedback(id_fed_pk) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela Agenda
CREATE TABLE Agenda (
    id_age_pk INT PRIMARY KEY AUTO_INCREMENT,
    agendados_age VARCHAR(100) NOT NULL,
    data_de_agendamento_age DATE NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela Evento
CREATE TABLE Evento (
    id_eve_pk INT PRIMARY KEY AUTO_INCREMENT,
    descricao_eve VARCHAR(100) NOT NULL,
    local_eve VARCHAR(100) NOT NULL,
    data_inicio_eve DATE NOT NULL,
    data_final_eve DATE,
    hora_eve TIME,
    id_age_fk INT NOT NULL,
    FOREIGN KEY (id_age_fk) REFERENCES Agenda(id_age_pk) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela Ponto_de_Coleta
CREATE TABLE Ponto_de_Coleta (
    id_pont_pk INT PRIMARY KEY AUTO_INCREMENT,
    nome_pon VARCHAR(100) NOT NULL,
    tipo_pon VARCHAR(100) NOT NULL,
    descricao_pon VARCHAR(100) NOT NULL,
    horaFuncionamento_pon TIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela Consultoria
CREATE TABLE Consultoria (
    id_cons_pk INT PRIMARY KEY AUTO_INCREMENT,
    nome_cons VARCHAR(100) NOT NULL,
    descricao_cons VARCHAR(100) NOT NULL,
    tipo_cons VARCHAR(100) NOT NULL,
    data_cons DATE NOT NULL,
    orcamento_cons DECIMAL(10,2) NOT NULL,
    fk_Ponto_de_Coleta_id_pont_pk INT,
    FOREIGN KEY (fk_Ponto_de_Coleta_id_pont_pk) REFERENCES Ponto_de_Coleta(id_pont_pk) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela Orcamento
CREATE TABLE Orcamento (
    id_orc_pk INT PRIMARY KEY AUTO_INCREMENT,
    nome_da_empresa_orc VARCHAR(100) NOT NULL,
    descricao_orc VARCHAR(100) NOT NULL,
    tipo_de_objetivo_orc VARCHAR(100) NOT NULL,
    id_use_fk INT NOT NULL,
    id_cons_fk INT NOT NULL,
    FOREIGN KEY (id_use_fk) REFERENCES Usuario(id_use_pk) ON DELETE CASCADE,
    FOREIGN KEY (id_cons_fk) REFERENCES Consultoria(id_cons_pk) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela Arquivo
CREATE TABLE Arquivo (
    id_arq_pk INT PRIMARY KEY AUTO_INCREMENT,
    data_arq DATE NOT NULL,
    blob_arq BLOB,
    id_use_fk INT NOT NULL,
    FOREIGN KEY (id_use_fk) REFERENCES Usuario(id_use_pk) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de junção Noticia_Evento (N:M)
CREATE TABLE Noticia_Evento (
    fk_Noticia_id_noticia_pk INT,
    fk_Evento_id_eve_pk INT,
    PRIMARY KEY (fk_Noticia_id_noticia_pk, fk_Evento_id_eve_pk),
    FOREIGN KEY (fk_Noticia_id_noticia_pk) REFERENCES Noticia(id_noticia_pk) ON DELETE CASCADE,
    FOREIGN KEY (fk_Evento_id_eve_pk) REFERENCES Evento(id_eve_pk) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Demais Atividades

 -- Endereco
INSERT INTO Endereco (logradouro_end, numero_end, complemento_end, bairro_end, cidade_end, estado_end, cep_end, pais_end) VALUES
('Rua das Flores', '123', 'Apto 101', 'Centro', 'São Paulo', 'SP', '01001000', 'Brasil'),
('Avenida Brasil', '456', NULL, 'Jardins', 'Rio de Janeiro', 'RJ', '20040000', 'Brasil'),
('Rua das Palmeiras', '789', 'Sala 2', 'Barra', 'Salvador', 'BA', '40000000', 'Brasil'),
('Alameda Santos', '321', 'Bloco B', 'Moema', 'São Paulo', 'SP', '04507000', 'Brasil'),
('Rua das Acácias', '654', NULL, 'Boa Viagem', 'Recife', 'PE', '51011000', 'Brasil'),
('Avenida Paulista', '159', 'Andar 15', 'Bela Vista', 'São Paulo', 'SP', '01311000', 'Brasil');

-- Contato
INSERT INTO Contato (telefone_con, email_con) VALUES
('11999999999', 'joao@email.com'),
('21988888888', 'maria@email.com'),
('71977777777', 'pedro@email.com'),
('11966666666', 'ana@email.com'),
('81955555555', 'lucas@email.com'),
('21944444444', 'carla@email.com');

-- [Repita para todas as tabelas...]
-- (Adicione inserts para Usuario, Feedback, Noticia, Agenda, Evento, etc.)

-- Update 1: Atualizar orçamentos acima de R$ 10.000 usando BETWEEN
UPDATE Consultoria 
SET tipo_cons = 'Premium' 
WHERE orcamento_cons BETWEEN 10000 AND 50000;

-- Update 2: Atualizar eventos em SP usando LIKE
UPDATE Evento 
SET local_eve = 'São Paulo - Capital' 
WHERE local_eve LIKE '%SP%';

-- Delete 1: Remover feedbacks com avaliação nula
DELETE FROM Feedback 
WHERE avaliacao_feed IS NULL;

-- Delete 2: Remover usuários nascidos antes de 2000 usando operador <
DELETE FROM Usuario 
WHERE data_nasc_use < '2000-01-01';

-- 1. Usuários com notícias e feedbacks (INNER JOIN)
SELECT u.nome_completo_use, n.nome_da_noticia, f.comentario_feed
FROM Usuario u
INNER JOIN Noticia n ON u.id_use_pk = n.id_use_fk
INNER JOIN Feedback f ON n.fk_Feedback_id_fed_pk = f.id_fed_pk
WHERE f.curtida_feed = TRUE; 
-- Situação: Identificar usuários com notícias bem avaliadas

-- 2. Eventos com consultorias (LEFT JOIN)
SELECT e.descricao_eve, c.nome_cons
FROM Evento e
INNER JOIN Agenda a ON e.id_age_fk = a.id_age_pk
INNER JOIN Usuario u ON a.id_age_pk = u.id_use_pk
INNER JOIN Orcamento o ON u.id_use_pk = o.id_use_fk
INNER JOIN Consultoria c ON o.id_cons_fk = c.id_cons_pk
WHERE c.tipo_cons = 'Sustentabilidade';
-- Situação: Eventos vinculados a consultorias de sustentabilidade

-- [Adicione mais 2 selects...]

-- Trigger: Auditória ao atualizar orçamento
DELIMITER $$
CREATE TRIGGER tr_after_update_orcamento
AFTER UPDATE ON Orcamento
FOR EACH ROW
BEGIN
    INSERT INTO Auditoria (acao, tabela, data)
    VALUES ('UPDATE', 'Orcamento', NOW());
END$$
DELIMITER ;

-- Stored Procedure: Calcular média de orçamentos
DELIMITER $$
CREATE PROCEDURE sp_media_orcamentos()
BEGIN
    SELECT AVG(orcamento_cons) AS media FROM Consultoria;
END$$
DELIMITER ;

-- Function 1: Contar eventos por data
DELIMITER $$
CREATE FUNCTION fn_contar_eventos(data_p DATE) 
RETURNS INT
DETERMINISTIC
BEGIN
    RETURN (SELECT COUNT(*) FROM Evento WHERE data_inicio_eve = data_p);
END$$
DELIMITER ;

-- Function 2: Validar e-mail
DELIMITER $$
CREATE FUNCTION fn_validar_email(email VARCHAR(100)) 
RETURNS BOOLEAN
DETERMINISTIC
BEGIN
    RETURN email LIKE '%@%.%';
END$$
DELIMITER ;