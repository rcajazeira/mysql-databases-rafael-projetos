-- Criação do Banco de Dados
CREATE DATABASE SistemaEsportivo;
USE SistemaEsportivo;

-- Tabela Imprensa
CREATE TABLE Imprensa (
    id_imp_pk INT AUTO_INCREMENT PRIMARY KEY,
    nome_imp VARCHAR(100) NOT NULL,
    responsavel_imp VARCHAR(100),
    paginaweb_imp VARCHAR(255)
);

-- Tabela Estadio
CREATE TABLE Estadio (
    id_est_pk INT AUTO_INCREMENT PRIMARY KEY,
    nome_est VARCHAR(100) NOT NULL,
    localizacao_est VARCHAR(255),
    clube_est VARCHAR(100),
    marketing_est VARCHAR(100),
    vendas_est VARCHAR(100)
);

-- Tabela Funcionario
CREATE TABLE Funcionario (
    id_matricula_pk INT AUTO_INCREMENT PRIMARY KEY,
    nome_fun VARCHAR(100) NOT NULL,
    cpf_fun VARCHAR(14) UNIQUE NOT NULL,
    data_nasc_fun DATE,
    salario_fun DECIMAL(10, 2),
    data_de_admissao_fun DATE,
    data_de_finalizacao_de_contrato_fun DATE,
    tipo_de_contrato VARCHAR(50),
    funcao_fun VARCHAR(100),
    setor_fun VARCHAR(100),
    id_est_fk INT,  -- Chave estrangeira para Estadio
    FOREIGN KEY (id_est_fk) REFERENCES Estadio(id_est_pk)
);

-- Tabela Partida
CREATE TABLE Partida (
    id_parti_pk INT AUTO_INCREMENT PRIMARY KEY,
    resultado_part VARCHAR(50),
    data_part DATE,
    horario_parti TIME,
    tempo_total_part INT,
    id_est_fk INT,  -- Chave estrangeira para Estadio
    FOREIGN KEY (id_est_fk) REFERENCES Estadio(id_est_pk)
);

-- Tabela Torcida
CREATE TABLE Torcida (
    id_torc_pk INT AUTO_INCREMENT PRIMARY KEY,
    clube_torc VARCHAR(100),
    coordenacao_responsavel_torci VARCHAR(100),
    id_est_fk INT,  -- Chave estrangeira para Estadio
    FOREIGN KEY (id_est_fk) REFERENCES Estadio(id_est_pk)
);

-- Tabela Socio
CREATE TABLE Socio (
    id_socio_pk INT AUTO_INCREMENT PRIMARY KEY,
    clube_socio VARCHAR(100),
    filiacao_socio VARCHAR(100),
    vendas_socio VARCHAR(100),
    id_est_fk INT,  -- Chave estrangeira para Estadio
    FOREIGN KEY (id_est_fk) REFERENCES Estadio(id_est_pk)
);

-- Tabela Jogador
CREATE TABLE Jogador (
    id_matricula_pk INT AUTO_INCREMENT PRIMARY KEY,
    nome_jog VARCHAR(100) NOT NULL,
    cpf_jog VARCHAR(14) UNIQUE NOT NULL,
    filiacao_jog VARCHAR(100),
    posicao_jog VARCHAR(50),
    email_jog VARCHAR(100),
    remumeracao_jog DECIMAL(10, 2),
    id_est_fk INT,  -- Chave estrangeira para Estadio
    FOREIGN KEY (id_est_fk) REFERENCES Estadio(id_est_pk)
);

-- Tabela Endereco
CREATE TABLE Endereco (
    id_end_pk INT AUTO_INCREMENT PRIMARY KEY,
    pais_end VARCHAR(50),
    estado_end VARCHAR(50),
    cidade_end VARCHAR(100),
    bairro_end VARCHAR(100),
    logradouro_end VARCHAR(100),
    numero_end VARCHAR(10),
    cep_end VARCHAR(10),
    referencia_end VARCHAR(255),
    complemento_end VARCHAR(255),
    id_jog_fk INT,  -- Chave estrangeira para Jogador
    FOREIGN KEY (id_jog_fk) REFERENCES Jogador(id_matricula_pk)
);

-- Tabela Contato
CREATE TABLE Contato (
    id_con_pk INT AUTO_INCREMENT PRIMARY KEY,
    tipo_con VARCHAR(50),
    descricao_con VARCHAR(255),
    id_jog_fk INT,  -- Chave estrangeira para Jogador
    FOREIGN KEY (id_jog_fk) REFERENCES Jogador(id_matricula_pk)
);

-- Atividades


INSERT INTO Imprensa (nome_imp, responsavel_imp, paginaweb_imp)
VALUES 
('ESPN', 'João Silva', 'https://www.espn.com'),
('Globo Esporte', 'Maria Oliveira', 'https://ge.globo.com'),
('Fox Sports', 'Carlos Souza', 'https://www.foxsports.com'),
('Band Sports', 'Ana Costa', 'https://www.bandsports.com.br');

-- Tabela: Estadio


INSERT INTO Estadio (nome_est, localizacao_est, clube_est, marketing_est, vendas_est)
VALUES 
('Maracanã', 'Rio de Janeiro', 'Flamengo', 'Marketing RJ', 'Vendas RJ'),
('Morumbi', 'São Paulo', 'São Paulo', 'Marketing SP', 'Vendas SP'),
('Mineirão', 'Belo Horizonte', 'Cruzeiro', 'Marketing MG', 'Vendas MG'),
('Arena Grêmio', 'Porto Alegre', 'Grêmio', 'Marketing RS', 'Vendas RS');

-- Tabela: Funcionario

INSERT INTO Funcionario (nome_fun, cpf_fun, data_nasc_fun, salario_fun, data_de_admissao_fun, tipo_de_contrato, funcao_fun, setor_fun, id_est_fk)
VALUES 
('Pedro Alves', '123.456.789-00', '1985-05-15', 5000.00, '2020-01-10', 'CLT', 'Segurança', 'Operacional', 1),
('Ana Paula', '987.654.321-00', '1990-08-20', 6000.00, '2019-03-05', 'PJ', 'Gerente', 'Administrativo', 2),
('Carlos Mendes', '456.789.123-00', '1988-11-30', 4500.00, '2021-07-15', 'CLT', 'Recepcionista', 'Atendimento', 3),
('Juliana Costa', '321.654.987-00', '1995-02-25', 5500.00, '2022-02-01', 'PJ', 'Analista', 'Financeiro', 4);

-- Tabela: Partida


INSERT INTO Partida (resultado_part, data_part, horario_parti, tempo_total_part, id_est_fk)
VALUES 
('3x1', '2023-10-01', '16:00:00', 90, 1),
('2x2', '2023-10-02', '18:00:00', 90, 2),
('1x0', '2023-10-03', '20:00:00', 90, 3),
('4x2', '2023-10-04', '19:00:00', 90, 4);

-- Tabela: Torcida

INSERT INTO Torcida (clube_torc, coordenacao_responsavel_torci, id_est_fk)
VALUES 
('Flamengo', 'Coordenação RJ', 1),
('São Paulo', 'Coordenação SP', 2),
('Cruzeiro', 'Coordenação MG', 3),
('Grêmio', 'Coordenação RS', 4);

-- Tabela: Socio

INSERT INTO Socio (clube_socio, filiacao_socio, vendas_socio, id_est_fk)
VALUES 
('Flamengo', 'Sócio Ouro', 'Vendas RJ', 1),
('São Paulo', 'Sócio Prata', 'Vendas SP', 2),
('Cruzeiro', 'Sócio Bronze', 'Vendas MG', 3),
('Grêmio', 'Sócio Diamante', 'Vendas RS', 4);

-- Tabela: Jogador

INSERT INTO Jogador (nome_jog, cpf_jog, filiacao_jog, posicao_jog, email_jog, remumeracao_jog, id_est_fk)
VALUES 
('Gabriel Barbosa', '111.222.333-44', 'Flamengo', 'Atacante', 'gabigol@flamengo.com', 100000.00, 1),
('Luciano', '222.333.444-55', 'São Paulo', 'Atacante', 'luciano@saopaulo.com', 80000.00, 2),
('Fábio', '333.444.555-66', 'Cruzeiro', 'Goleiro', 'fabio@cruzeiro.com', 70000.00, 3),
('Diego Souza', '444.555.666-77', 'Grêmio', 'Atacante', 'diego@gremio.com', 90000.00, 4);

-- Tabela: Endereco

INSERT INTO Endereco (pais_end, estado_end, cidade_end, bairro_end, logradouro_end, numero_end, cep_end, referencia_end, complemento_end, id_jog_fk)
VALUES 
('Brasil', 'RJ', 'Rio de Janeiro', 'Tijuca', 'Rua A', '123', '20500-000', 'Próximo ao metrô', 'Casa 1', 1),
('Brasil', 'SP', 'São Paulo', 'Morumbi', 'Rua B', '456', '05600-000', 'Próximo ao estádio', 'Apartamento 2', 2),
('Brasil', 'MG', 'Belo Horizonte', 'Savassi', 'Rua C', '789', '30100-000', 'Próximo ao shopping', 'Casa 3', 3),
('Brasil', 'RS', 'Porto Alegre', 'Moinhos de Vento', 'Rua D', '101', '90500-000', 'Próximo ao parque', 'Apartamento 4', 4);

-- Tabela: Contato

INSERT INTO Contato (tipo_con, descricao_con, id_jog_fk)
VALUES 
('Telefone', '(21) 99999-9999', 1),
('E-mail', 'gabigol@flamengo.com', 1),
('Telefone', '(11) 88888-8888', 2),
('E-mail', 'luciano@saopaulo.com', 2);

-- 2. UPDATE (Atualizações)

-- Tabela: Funcionario

-- Aumenta o salário dos funcionários admitidos antes de 2021
UPDATE Funcionario
SET salario_fun = salario_fun * 1.10
WHERE data_de_admissao_fun < '2021-01-01';

-- Atualiza o setor de um funcionário específico
UPDATE Funcionario
SET setor_fun = 'Marketing'
WHERE id_matricula_pk = 1;

-- Tabela: Jogador

-- Aumenta a remuneração dos jogadores que ganham menos de 90000
UPDATE Jogador
SET remumeracao_jog = remumeracao_jog + 10000
WHERE remumeracao_jog < 90000;

-- Atualiza o e-mail de um jogador específico
UPDATE Jogador
SET email_jog = 'novoemail@gremio.com'
WHERE id_matricula_pk = 4;

-- 3. DELETE (Exclusões)

-- Tabela: Contato

-- Remove contatos do tipo 'Telefone'
DELETE FROM Contato
WHERE tipo_con = 'Telefone';

-- Tabela: Partida

-- Remove partidas que ocorreram antes de 2023-10-03
DELETE FROM Partida
WHERE data_part < '2023-10-03';

-- 4. SELECT (Consultas)
SELECT 1: Listar jogadores com remuneração acima de 80000

-- Objetivo: Retornar os jogadores que ganham mais de 80000
SELECT nome_jog, posicao_jog, remumeracao_jog
FROM Jogador
WHERE remumeracao_jog > 80000;

-- SELECT 2: Listar funcionários admitidos entre 2020 e 2021


-- Objetivo: Retornar funcionários admitidos no período de 2020 a 2021
SELECT nome_fun, data_de_admissao_fun, setor_fun
FROM Funcionario
WHERE data_de_admissao_fun BETWEEN '2020-01-01' AND '2021-12-31';

-- SELECT 3: Listar estádios localizados no Rio de Janeiro ou São Paulo

-- Objetivo: Retornar estádios localizados no RJ ou SP
SELECT nome_est, localizacao_est
FROM Estadio
WHERE localizacao_est LIKE '%Rio de Janeiro%' OR localizacao_est LIKE '%São Paulo%';

-- 5. TRIGGER

Trigger: Atualizar data de término de contrato ao demitir um funcionário
sql
Copy
DELIMITER //
CREATE TRIGGER trg_demitir_funcionario
BEFORE DELETE ON Funcionario
FOR EACH ROW
BEGIN
    UPDATE Funcionario
    SET data_de_finalizacao_de_contrato_fun = CURDATE()
    WHERE id_matricula_pk = OLD.id_matricula_pk;
END //
DELIMITER ;
6. STORED PROCEDURE
Procedure: Calcular média salarial dos funcionários
sql
Copy
DELIMITER //
CREATE PROCEDURE sp_calcular_media_salarial()
BEGIN
    SELECT AVG(salario_fun) AS media_salarial
    FROM Funcionario;
END //
DELIMITER ;
7. FUNCTION
Function: Verificar se um jogador é bem remunerado
sql
Copy
DELIMITER //
CREATE FUNCTION fn_jogador_bem_remunerado(remuneracao DECIMAL(10,2))
RETURNS VARCHAR(50)
DETERMINISTIC
BEGIN
    IF remuneracao > 90000 THEN
        RETURN 'Bem remunerado';
    ELSE
        RETURN 'Remuneração normal';
    END IF;
END //
DELIMITER ;

-- Como usar a function:


SELECT nome_jog, remumeracao_jog, fn_jogador_bem_remunerado(remumeracao_jog) AS status_remuneracao
FROM Jogador;